Create database RapidSolution
go
use RapidSolution
go
Create table [MasterBill]
(
	Id int identity primary key,
	MasterAirWayBill varchar(100) unique,
	DateCreated DateTime default getdate(),
	DateArrived DateTime
)
go
Create table BoxInfo
(
	Id int identity primary key,
	BoxId varchar(100) unique,
	DateCreated DateTime default getdate(),
	ShipmentQuantity int,
	MasterBillId int references MasterBill(Id)
)
go
Create table ShipmentInfor
(
	Id int identity primary key,
	ShipmentId varchar(100) unique,
	DateCreated DateTime default getdate(),
	Sender nvarchar(300),
	Receiver nvarchar(300),
	TelReceiver varchar(50),
	TotalValue float,
	Descrition nvarchar(1000),
	BoxId int references BoxInfo(Id)
)
go
Create table ShipmentOut
(
	ShipmentId varchar(100) references ShipmentInfor(ShipmentId) primary key,
	DateOut DateTime
)